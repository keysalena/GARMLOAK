<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Admin GARML')</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>

<body class="admin-body">
    <div class="admin-shell-panel">
        @include('admin.partials.sidebar')

        <div class="admin-content-wrap">
            <header class="topbar">
                <label class="search-box" aria-label="Search">
                    <svg viewBox="0 0 24 24" aria-hidden="true">
                        <path d="M10.5 3.5a7 7 0 1 1 0 14 7 7 0 0 1 0-14Zm9.2 19.2-5.6-5.6 1.4-1.4 5.6 5.6-1.4 1.4Z" />
                    </svg>
                    <input type="text" placeholder="Search task" />
                    <span class="hotkey">⌘F</span>
                </label>

                <div class="topbar-actions">
                    <button class="icon-btn" aria-label="Inbox">
                        <svg viewBox="0 0 24 24" aria-hidden="true">
                            <path d="M5 7.5A2.5 2.5 0 0 1 7.5 5h9A2.5 2.5 0 0 1 19 7.5v8.9a2.6 2.6 0 0 1-2.6 2.6H7.6A2.6 2.6 0 0 1 5 16.4V7.5Zm2.5-.5a.5.5 0 0 0-.5.5v.6h10v-.6a.5.5 0 0 0-.5-.5h-9Zm-.5 4.1h10v5.8a1.1 1.1 0 0 1-1.1 1.1H7.6A1.1 1.1 0 0 1 6.5 17.1v-5.8Zm1.8 1.1v1.4h6.4v-1.4H8.3Z" />
                        </svg>
                    </button>
                    <button class="icon-btn" aria-label="Notifications">
                        <svg viewBox="0 0 24 24" aria-hidden="true">
                            <path d="M12 3.5a5.5 5.5 0 0 1 5.5 5.5v3.4l1.5 3.9h-14l1.5-3.9V9A5.5 5.5 0 0 1 12 3.5Zm0 17a2.2 2.2 0 0 1-2.2-2.2h4.4A2.2 2.2 0 0 1 12 20.5Z" />
                        </svg>
                    </button>
                    <div class="profile-badge">
                        <div class="avatar">T</div>
                        <div>
                            <strong>Totok Michael</strong>
                            <small>tmichael20@gmail.com</small>
                        </div>
                    </div>
                </div>
            </header>

            <main class="admin-main">
                @yield('content')
            </main>
        </div>
    </div>

    <div class="modal-backdrop" id="globalModal" aria-hidden="true">
        <div class="modal-card" role="dialog" aria-modal="true" aria-labelledby="modalTitle">
            <button type="button" class="modal-close" aria-label="Close">×</button>
            <div class="modal-body" id="modalContent"></div>
        </div>
    </div>
</body>

</html>