@extends('layouts.admin')

@section('title', 'Kelas')

@section('content')
<div class="page-header">
    <div>
        <p class="eyebrow text-green">Data</p>
        <h1>Kelola Kelas</h1>
    </div>
    <button type="button" class="btn btn-primary" data-modal-open="{{ route('admin.kelas.create') }}" data-modal-title="Tambah Kelas">+ Tambah Kelas</button>
</div>

<div class="panel-card">
    <div class="panel-header">
        <h3>Daftar Kelas</h3>
        <span class="pill neutral">{{ $items->count() }} item</span>
    </div>

    <table class="data-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama Kelas</th>
                <th>Tahun Ajaran</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($items as $item)
            <tr>
                <td>{{ $item->kelas_id }}</td>
                <td>{{ $item->nama_kelas }}</td>
                <td>{{ $item->tahun_ajaran ?? '-' }}</td>
                <td class="action-cell">
                    <button type="button" class="btn btn-small btn-secondary" data-modal-open="{{ route('admin.kelas.edit', $item->kelas_id) }}" data-modal-title="Edit Kelas">Edit</button>
                    <form action="{{ route('admin.kelas.destroy', $item->kelas_id) }}" method="POST" onsubmit="return confirm('Hapus kelas ini?');">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-small btn-danger">Hapus</button>
                    </form>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="4" class="empty-state">Belum ada data kelas.</td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection