@extends('layouts.admin')

@section('title', ($mode ?? 'create') === 'edit' ? 'Edit Kelas' : 'Tambah Kelas')

@section('content')
<div class="page-header">
    <div>
        <p class="eyebrow text-green">Kelas</p>
        <h1>{{ ($mode ?? 'create') === 'edit' ? 'Edit Kelas' : 'Tambah Kelas' }}</h1>
    </div>
</div>

<div class="panel-card">
    <form method="POST" action="{{ ($mode ?? 'create') === 'edit' ? route('admin.kelas.update', $data->kelas_id) : route('admin.kelas.store') }}" class="login-form">
        @csrf
        @if (($mode ?? 'create') === 'edit')
        @method('PUT')
        @endif

        <label class="field-group">
            <span>Nama Kelas</span>
            <input type="text" name="nama_kelas" value="{{ old('nama_kelas', $data->nama_kelas ?? '') }}" required>
        </label>

        <label class="field-group">
            <span>Tahun Ajaran</span>
            <input type="text" name="tahun_ajaran" value="{{ old('tahun_ajaran', $data->tahun_ajaran ?? '') }}">
        </label>

        <div class="action-cell">
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="{{ route('admin.kelas.index') }}" class="btn btn-secondary">Batal</a>
        </div>
    </form>
</div>
@endsection