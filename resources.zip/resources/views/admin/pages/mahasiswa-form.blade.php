@extends('layouts.admin')

@section('title', ($mode ?? 'create') === 'edit' ? 'Edit Mahasiswa' : 'Tambah Mahasiswa')

@section('content')
<div class="page-header">
    <div>
        <p class="eyebrow text-green">Mahasiswa</p>
        <h1>{{ ($mode ?? 'create') === 'edit' ? 'Edit Mahasiswa' : 'Tambah Mahasiswa' }}</h1>
    </div>
</div>

<div class="panel-card">
    <form method="POST" action="{{ ($mode ?? 'create') === 'edit' ? route('admin.mahasiswa.update', $data->user_id) : route('admin.mahasiswa.store') }}" class="login-form">
        @csrf
        @if (($mode ?? 'create') === 'edit')
        @method('PUT')
        @endif

        <label class="field-group">
            <span>Nama</span>
            <input type="text" name="nama" value="{{ old('nama', $data->nama ?? '') }}" required>
        </label>

        <label class="field-group">
            <span>Email</span>
            <input type="email" name="email" value="{{ old('email', $data->email ?? '') }}" required>
        </label>

        <label class="field-group">
            <span>Password</span>
            <input type="password" name="password" placeholder="Kosongkan jika tidak ingin mengubah">
        </label>

        <div class="action-cell">
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="{{ route('admin.mahasiswa.index') }}" class="btn btn-secondary">Batal</a>
        </div>
    </form>
</div>
@endsection