@extends('layouts.admin')

@section('title', ($mode ?? 'create') === 'edit' ? 'Edit Modul' : 'Tambah Modul')

@section('content')
<div class="page-header">
    <div>
        <p class="eyebrow text-green">Modul</p>
        <h1>{{ ($mode ?? 'create') === 'edit' ? 'Edit Modul' : 'Tambah Modul' }}</h1>
    </div>
</div>

<div class="panel-card">
    <form method="POST" action="{{ ($mode ?? 'create') === 'edit' ? route('admin.modul.update', $data->module_id) : route('admin.modul.store') }}" class="login-form">
        @csrf
        @if (($mode ?? 'create') === 'edit')
        @method('PUT')
        @endif

        <label class="field-group">
            <span>Kode Modul</span>
            <input type="text" name="kode_modul" value="{{ old('kode_modul', $data->kode_modul ?? '') }}" required>
        </label>

        <label class="field-group">
            <span>Judul</span>
            <input type="text" name="judul" value="{{ old('judul', $data->judul ?? '') }}" required>
        </label>

        <label class="field-group">
            <span>Sub CPMK</span>
            <input type="text" name="sub_cpmk" value="{{ old('sub_cpmk', $data->sub_cpmk ?? '') }}">
        </label>

        <label class="field-group">
            <span>Deskripsi</span>
            <textarea name="deskripsi" rows="4">{{ old('deskripsi', $data->deskripsi ?? '') }}</textarea>
        </label>

        <div class="action-cell">
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="{{ route('admin.modul.index') }}" class="btn btn-secondary">Batal</a>
        </div>
    </form>
</div>
@endsection