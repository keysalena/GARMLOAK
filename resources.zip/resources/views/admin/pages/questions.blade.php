@extends('layouts.admin')

@section('title', 'Questions')

@section('content')
<div class="page-header">
    <div>
        <p class="eyebrow text-green">Latihan</p>
        <h1>Kelola Questions</h1>
    </div>
    <button type="button" class="btn btn-primary" data-modal-open="{{ route('admin.questions.create') }}" data-modal-title="Tambah Question">+ Tambah Question</button>
</div>

<div class="panel-card">
    <div class="panel-header">
        <h3>Daftar Pertanyaan</h3>
        <span class="pill neutral">{{ $items->count() }} item</span>
    </div>

    <table class="data-table">
        <thead>
            <tr>
                <th>Pertanyaan</th>
                <th>Challenge</th>
                <th>XP</th>
                <th>Urutan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($items as $item)
            <tr>
                <td>{{ \Illuminate\Support\Str::limit($item->pertanyaan, 70) }}</td>
                <td>{{ $item->challenge?->judul ?? '-' }}</td>
                <td>{{ $item->xp_reward }}</td>
                <td>{{ $item->urutan }}</td>
                <td class="action-cell">
                    <button type="button" class="btn btn-small btn-secondary" data-modal-open="{{ route('admin.questions.edit', $item->question_id) }}" data-modal-title="Edit Question">Edit</button>
                    <form action="{{ route('admin.questions.destroy', $item->question_id) }}" method="POST" onsubmit="return confirm('Hapus pertanyaan ini?');">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-small btn-danger">Hapus</button>
                    </form>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="5" class="empty-state">Belum ada pertanyaan.</td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection