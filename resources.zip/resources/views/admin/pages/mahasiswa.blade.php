@extends('layouts.admin')

@section('title', 'Mahasiswa')

@section('content')
<div class="page-header">
    <div>
        <p class="eyebrow text-green">Data</p>
        <h1>Kelola Mahasiswa</h1>
    </div>
    <button type="button" class="btn btn-primary" data-modal-open="{{ route('admin.mahasiswa.create') }}" data-modal-title="Tambah Mahasiswa">+ Tambah Mahasiswa</button>
</div>

<div class="panel-card">
    <div class="panel-header">
        <h3>Daftar Mahasiswa</h3>
        <span class="pill neutral">{{ $items->count() }} item</span>
    </div>

    <table class="data-table">
        <thead>
            <tr>
                <th>Nama</th>
                <th>Email</th>
                <th>Kelas</th>
                <th>Level</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($items as $item)
            <tr>
                <td>{{ $item->nama }}</td>
                <td>{{ $item->email }}</td>
                <td>{{ $item->kelas?->nama_kelas ?? '-' }}</td>
                <td>{{ $item->level }}</td>
                <td class="action-cell">
                    <button type="button" class="btn btn-small btn-secondary" data-modal-open="{{ route('admin.mahasiswa.edit', $item->user_id) }}" data-modal-title="Edit Mahasiswa">Edit</button>
                    <form action="{{ route('admin.mahasiswa.destroy', $item->user_id) }}" method="POST" onsubmit="return confirm('Hapus mahasiswa ini?');">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-small btn-danger">Hapus</button>
                    </form>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="5" class="empty-state">Belum ada mahasiswa.</td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection