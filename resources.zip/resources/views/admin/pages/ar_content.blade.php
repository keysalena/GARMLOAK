@extends('layouts.admin')

@section('title', 'AR Content')

@section('content')
<div class="page-header">
    <div>
        <p class="eyebrow text-green">Konten</p>
        <h1>Kelola AR Content</h1>
    </div>
    <button type="button" class="btn btn-primary" data-modal-open="{{ route('admin.ar-content.create') }}" data-modal-title="Tambah AR Content">+ Tambah AR</button>
</div>

<div class="panel-card">
    <div class="panel-header">
        <h3>Daftar AR Content</h3>
        <span class="pill neutral">{{ $items->count() }} item</span>
    </div>

    <table class="data-table">
        <thead>
            <tr>
                <th>Judul</th>
                <th>Modul</th>
                <th>Urutan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($items as $item)
            <tr>
                <td>{{ $item->judul }}</td>
                <td>{{ $item->module?->judul ?? '-' }}</td>
                <td>{{ $item->urutan }}</td>
                <td class="action-cell">
                    <button type="button" class="btn btn-small btn-secondary" data-modal-open="{{ route('admin.ar-content.edit', $item->ar_id) }}" data-modal-title="Edit AR Content">Edit</button>
                    <form action="{{ route('admin.ar-content.destroy', $item->ar_id) }}" method="POST" onsubmit="return confirm('Hapus AR content ini?');">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-small btn-danger">Hapus</button>
                    </form>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="4" class="empty-state">Belum ada AR content.</td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection