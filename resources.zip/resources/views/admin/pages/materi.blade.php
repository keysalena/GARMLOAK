@extends('layouts.admin')

@section('title', 'Materi')

@section('content')
<div class="page-header">
    <div>
        <p class="eyebrow text-green">Konten</p>
        <h1>Kelola Materi</h1>
    </div>
    <button type="button" class="btn btn-primary" data-modal-open="{{ route('admin.materi.create') }}" data-modal-title="Tambah Materi">+ Tambah Materi</button>
</div>

<div class="panel-card">
    <div class="panel-header">
        <h3>Daftar Materi</h3>
        <span class="pill neutral">{{ $items->count() }} item</span>
    </div>

    <table class="data-table">
        <thead>
            <tr>
                <th>Judul</th>
                <th>Modul</th>
                <th>Tipe</th>
                <th>Urutan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($items as $item)
            <tr>
                <td>{{ $item->judul }}</td>
                <td>{{ $item->module?->judul ?? '-' }}</td>
                <td>{{ $item->tipe }}</td>
                <td>{{ $item->urutan }}</td>
                <td class="action-cell">
                    <button type="button" class="btn btn-small btn-secondary" data-modal-open="{{ route('admin.materi.edit', $item->materi_id) }}" data-modal-title="Edit Materi">Edit</button>
                    <form action="{{ route('admin.materi.destroy', $item->materi_id) }}" method="POST" onsubmit="return confirm('Hapus materi ini?');">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-small btn-danger">Hapus</button>
                    </form>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="5" class="empty-state">Belum ada materi.</td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection