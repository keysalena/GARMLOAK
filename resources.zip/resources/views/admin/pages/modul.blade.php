@extends('layouts.admin')

@section('title', 'Modul')

@section('content')
<div class="page-header">
    <div>
        <p class="eyebrow text-green">Konten</p>
        <h1>Kelola Modul</h1>
    </div>
    <button type="button" class="btn btn-primary" data-modal-open="{{ route('admin.modul.create') }}" data-modal-title="Tambah Modul">+ Tambah Modul</button>
</div>

<div class="panel-card">
    <div class="panel-header">
        <h3>Daftar Modul</h3>
        <span class="pill neutral">{{ $items->count() }} item</span>
    </div>

    <table class="data-table">
        <thead>
            <tr>
                <th>Kode</th>
                <th>Judul</th>
                <th>Sub CPMK</th>
                <th>Urutan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($items as $item)
            <tr>
                <td>{{ $item->kode_modul }}</td>
                <td>{{ $item->judul }}</td>
                <td>{{ $item->sub_cpmk ?? '-' }}</td>
                <td>{{ $item->urutan }}</td>
                <td class="action-cell">
                    <button type="button" class="btn btn-small btn-secondary" data-modal-open="{{ route('admin.modul.edit', $item->module_id) }}" data-modal-title="Edit Modul">Edit</button>
                    <form action="{{ route('admin.modul.destroy', $item->module_id) }}" method="POST" onsubmit="return confirm('Hapus modul ini?');">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-small btn-danger">Hapus</button>
                    </form>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="5" class="empty-state">Belum ada data modul.</td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection