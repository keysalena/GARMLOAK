@extends('layouts.admin')

@section('title', 'Challenge')

@section('content')
<div class="page-header">
    <div>
        <p class="eyebrow text-green">Latihan</p>
        <h1>Kelola Challenge</h1>
    </div>
    <button type="button" class="btn btn-primary" data-modal-open="{{ route('admin.challenge.create') }}" data-modal-title="Tambah Challenge">+ Tambah Challenge</button>
</div>

<div class="panel-card">
    <div class="panel-header">
        <h3>Daftar Challenge</h3>
        <span class="pill neutral">{{ $items->count() }} item</span>
    </div>

    <table class="data-table">
        <thead>
            <tr>
                <th>Judul</th>
                <th>Modul</th>
                <th>Jumlah Soal</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($items as $item)
            <tr>
                <td>{{ $item->judul }}</td>
                <td>{{ $item->module?->judul ?? '-' }}</td>
                <td>{{ $item->jumlah_soal }}</td>
                <td class="action-cell">
                    <button type="button" class="btn btn-small btn-secondary" data-modal-open="{{ route('admin.challenge.edit', $item->challenge_id) }}" data-modal-title="Edit Challenge">Edit</button>
                    <form action="{{ route('admin.challenge.destroy', $item->challenge_id) }}" method="POST" onsubmit="return confirm('Hapus challenge ini?');">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-small btn-danger">Hapus</button>
                    </form>
                </td>
            </tr>
            @empty
            <tr>
                <td colspan="4" class="empty-state">Belum ada challenge.</td>
            </tr>
            @endforelse
        </tbody>
    </table>
</div>
@endsection