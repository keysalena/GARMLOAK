@extends('layouts.admin')

@section('title', ($mode ?? 'create') === 'edit' ? 'Edit Materi' : 'Tambah Materi')

@section('content')
<div class="page-header">
    <div>
        <p class="eyebrow text-green">Materi</p>
        <h1>{{ ($mode ?? 'create') === 'edit' ? 'Edit Materi' : 'Tambah Materi' }}</h1>
    </div>
</div>

<div class="panel-card">
    <form method="POST" action="{{ ($mode ?? 'create') === 'edit' ? route('admin.materi.update', $data->materi_id) : route('admin.materi.store') }}" class="login-form">
        @csrf
        @if (($mode ?? 'create') === 'edit')
        @method('PUT')
        @endif

        <label class="field-group">
            <span>Judul</span>
            <input type="text" name="judul" value="{{ old('judul', $data->judul ?? '') }}" required>
        </label>

        <label class="field-group">
            <span>Modul</span>
            <select name="module_id">
                @foreach ($modules as $module)
                <option value="{{ $module->module_id }}" {{ old('module_id', $data->module_id ?? '') == $module->module_id ? 'selected' : '' }}>{{ $module->judul }}</option>
                @endforeach
            </select>
        </label>

        <label class="field-group">
            <span>Tipe</span>
            <select name="tipe">
                <option value="teks" {{ old('tipe', $data->tipe ?? '') == 'teks' ? 'selected' : '' }}>teks</option>
                <option value="video" {{ old('tipe', $data->tipe ?? '') == 'video' ? 'selected' : '' }}>video</option>
                <option value="pdf" {{ old('tipe', $data->tipe ?? '') == 'pdf' ? 'selected' : '' }}>pdf</option>
                <option value="kuis_singkat" {{ old('tipe', $data->tipe ?? '') == 'kuis_singkat' ? 'selected' : '' }}>kuis_singkat</option>
            </select>
        </label>

        <div class="action-cell">
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="{{ route('admin.materi.index') }}" class="btn btn-secondary">Batal</a>
        </div>
    </form>
</div>
@endsection