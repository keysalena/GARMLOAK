@extends('layouts.admin')

@section('title', ($mode ?? 'create') === 'edit' ? 'Edit AR Content' : 'Tambah AR Content')

@section('content')
<div class="page-header">
    <div>
        <p class="eyebrow text-green">AR Content</p>
        <h1>{{ ($mode ?? 'create') === 'edit' ? 'Edit AR Content' : 'Tambah AR Content' }}</h1>
    </div>
</div>

<div class="panel-card">
    <form method="POST" action="{{ ($mode ?? 'create') === 'edit' ? route('admin.ar-content.update', $data->ar_id) : route('admin.ar-content.store') }}" class="login-form">
        @csrf
        @if (($mode ?? 'create') === 'edit')
        @method('PUT')
        @endif

        <label class="field-group">
            <span>Judul</span>
            <input type="text" name="judul" value="{{ old('judul', $data->judul ?? '') }}" required>
        </label>

        <label class="field-group">
            <span>Modul</span>
            <select name="module_id">
                @foreach ($modules as $module)
                <option value="{{ $module->module_id }}" {{ old('module_id', $data->module_id ?? '') == $module->module_id ? 'selected' : '' }}>{{ $module->judul }}</option>
                @endforeach
            </select>
        </label>

        <label class="field-group">
            <span>Penjelasan</span>
            <textarea name="penjelasan" rows="4">{{ old('penjelasan', $data->penjelasan ?? '') }}</textarea>
        </label>

        <div class="action-cell">
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="{{ route('admin.ar-content.index') }}" class="btn btn-secondary">Batal</a>
        </div>
    </form>
</div>
@endsection