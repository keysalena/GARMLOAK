@extends('layouts.admin')

@section('title', ($mode ?? 'create') === 'edit' ? 'Edit Question' : 'Tambah Question')

@section('content')
<div class="page-header">
    <div>
        <p class="eyebrow text-green">Questions</p>
        <h1>{{ ($mode ?? 'create') === 'edit' ? 'Edit Question' : 'Tambah Question' }}</h1>
    </div>
</div>

<div class="panel-card">
    <form method="POST" action="{{ ($mode ?? 'create') === 'edit' ? route('admin.questions.update', $data->question_id) : route('admin.questions.store') }}" class="login-form">
        @csrf
        @if (($mode ?? 'create') === 'edit')
        @method('PUT')
        @endif

        <label class="field-group">
            <span>Challenge</span>
            <select name="challenge_id">
                @foreach ($challenges as $challenge)
                <option value="{{ $challenge->challenge_id }}" {{ old('challenge_id', $data->challenge_id ?? '') == $challenge->challenge_id ? 'selected' : '' }}>{{ $challenge->judul }}</option>
                @endforeach
            </select>
        </label>

        <label class="field-group">
            <span>Pertanyaan</span>
            <textarea name="pertanyaan" rows="4" required>{{ old('pertanyaan', $data->pertanyaan ?? '') }}</textarea>
        </label>

        <label class="field-group">
            <span>XP Reward</span>
            <input type="number" name="xp_reward" value="{{ old('xp_reward', $data->xp_reward ?? 30) }}">
        </label>

        <div class="action-cell">
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="{{ route('admin.questions.index') }}" class="btn btn-secondary">Batal</a>
        </div>
    </form>
</div>
@endsection