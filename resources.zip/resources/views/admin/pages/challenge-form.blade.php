@extends('layouts.admin')

@section('title', ($mode ?? 'create') === 'edit' ? 'Edit Challenge' : 'Tambah Challenge')

@section('content')
<div class="page-header">
    <div>
        <p class="eyebrow text-green">Challenge</p>
        <h1>{{ ($mode ?? 'create') === 'edit' ? 'Edit Challenge' : 'Tambah Challenge' }}</h1>
    </div>
</div>

<div class="panel-card">
    <form method="POST" action="{{ ($mode ?? 'create') === 'edit' ? route('admin.challenge.update', $data->challenge_id) : route('admin.challenge.store') }}" class="login-form">
        @csrf
        @if (($mode ?? 'create') === 'edit')
        @method('PUT')
        @endif

        <label class="field-group">
            <span>Judul</span>
            <input type="text" name="judul" value="{{ old('judul', $data->judul ?? '') }}" required>
        </label>

        <label class="field-group">
            <span>Modul</span>
            <select name="module_id">
                @foreach ($modules as $module)
                <option value="{{ $module->module_id }}" {{ old('module_id', $data->module_id ?? '') == $module->module_id ? 'selected' : '' }}>{{ $module->judul }}</option>
                @endforeach
            </select>
        </label>

        <div class="action-cell">
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="{{ route('admin.challenge.index') }}" class="btn btn-secondary">Batal</a>
        </div>
    </form>
</div>
@endsection