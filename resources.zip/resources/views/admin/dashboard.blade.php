@extends('layouts.admin')

@section('title', 'Dashboard Admin')

@section('content')
<div class="dashboard-header">
    <div>
        <p class="eyebrow text-green">Overview</p>
        <h1>Dashboard</h1>
    </div>
    <div class="header-actions">
        <button type="button" class="btn btn-primary" data-modal-open="{{ route('admin.modul.create') }}">+ Add Project</button>
        <button type="button" class="btn btn-secondary btn-outline">Import Data</button>
    </div>
</div>

<div class="stats-grid">
    <div class="stat-card accent-green">
        <div class="stat-top">
            <span class="stat-label">Total Projects</span>
            <span class="stat-arrow">↗</span>
        </div>
        <strong>{{ $totalModul }}</strong>
        <small>Increased from last month</small>
    </div>
    <div class="stat-card accent-light">
        <div class="stat-top">
            <span class="stat-label">Ended Projects</span>
            <span class="stat-arrow">↗</span>
        </div>
        <strong>{{ $totalChallenge }}</strong>
        <small>Increased from last month</small>
    </div>
    <div class="stat-card">
        <div class="stat-top">
            <span class="stat-label">Running Projects</span>
            <span class="stat-arrow">↗</span>
        </div>
        <strong>{{ $totalKelas }}</strong>
        <small>Increased from last month</small>
    </div>
    <div class="stat-card soft-card">
        <div class="stat-top">
            <span class="stat-label">Pending Project</span>
            <span class="stat-arrow muted">↗</span>
        </div>
        <strong>{{ $totalMahasiswa }}</strong>
        <small>On Discuss</small>
    </div>
</div>

<div class="content-grid two-column">
    <div class="panel-card analytics-card">
        <div class="panel-header">
            <h3>Project Analytics</h3>
        </div>
        <div class="analytics-graph">
            <div class="bar-group">
                <span class="bar bar-1" style="height: 42%"></span>
                <span class="bar bar-2" style="height: 58%"></span>
                <span class="bar bar-3" style="height: 72%"></span>
                <span class="bar bar-4" style="height: 64%"></span>
                <span class="bar bar-5" style="height: 78%"></span>
                <span class="bar bar-6" style="height: 48%"></span>
                <span class="bar bar-7" style="height: 56%"></span>
            </div>
            <div class="week-labels">
                <span>S</span><span>M</span><span>T</span><span>W</span><span>T</span><span>F</span><span>S</span>
            </div>
        </div>
    </div>

    <div class="panel-card reminders-card">
        <div class="panel-header">
            <h3>Reminders</h3>
        </div>
        <ul class="reminder-list">
            <li>
                <span class="reminder-time">Meeting with Arc Company</span>
                <small>Time : 02:00 pm - 04:00 pm</small>
            </li>
        </ul>
        <button class="btn btn-primary btn-block">Start Meeting</button>
    </div>
</div>

<div class="bottom-grid">
    <div class="panel-card team-card">
        <div class="panel-header">
            <h3>Team Collaboration</h3>
            <button class="btn btn-secondary btn-outline small-btn">+ Add Member</button>
        </div>
        <ul class="team-list">
            <li>
                <span class="avatar small avatar-pink">A</span>
                <div>
                    <strong>Alexandra Deff</strong>
                    <small>Working on Github Project Repository</small>
                </div>
                <span class="status-tag success">Completed</span>
            </li>
            <li>
                <span class="avatar small avatar-green">E</span>
                <div>
                    <strong>Edwin Adenike</strong>
                    <small>Working on Integrate User Authentication System</small>
                </div>
                <span class="status-tag process">In Progress</span>
            </li>
        </ul>
    </div>

    <div class="panel-card progress-card">
        <div class="panel-header">
            <h3>Project Progress</h3>
        </div>
        <div class="progress-ring">
            <div class="ring-value">41%</div>
            <div class="ring-label">Project Ended</div>
        </div>
    </div>

    <div class="panel-card task-card">
        <div class="panel-header">
            <h3>Project</h3>
            <button class="btn btn-secondary btn-outline small-btn">+ New</button>
        </div>
        <ul class="project-list">
            <li>Develop API Endpoints <span>Due date: Nov 28, 2024</span></li>
            <li>Onboarding Flow <span>Due date: Nov 28, 2024</span></li>
            <li>Build Dashboard <span>Due date: Nov 30, 2024</span></li>
            <li>Optimize Page Load <span>Due date: Dec 5, 2024</span></li>
            <li>Cross-Browser Testing <span>Due date: Dec 6, 2024</span></li>
        </ul>
    </div>

    <div class="panel-card timer-card">
        <div class="panel-header">
            <h3>Time Tracker</h3>
        </div>
        <div class="timer-display">
            <span>01:24:08</span>
        </div>
    </div>
</div>
@endsection